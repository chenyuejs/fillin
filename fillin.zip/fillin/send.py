import smtplib
import datetime
from email import encoders
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
#sender是邮件发送人邮箱，passWord是服务器授权码，mail_host是服务器地址（这里是QQsmtp服务器）
def send_email():
 sender = ''#你的邮箱
 passWord = ''#密钥
 mail_host = 'smtp.qq.com'
 #receivers是邮件接收人，用列表保存，可以添加多个
 receivers = ['xxx@outlook.com','xxx@qq.com']

 #设置email信息
 msg = MIMEMultipart()
#邮件主题
 msg['Subject'] ='今天的填写已经完成！'
#发送方信息
 msg['From'] = sender
#邮件正文是MIMEText:
 now_time = datetime.datetime.now()
 msg_content = '填写时间为：'+str(now_time)
 msg.attach(MIMEText(msg_content, 'plain', 'utf-8'))
# 添加附件就是加上一个MIMEBase，从本地读取一个图片:


#登录并发送邮件
 try:
    #QQsmtp服务器的端口号为465或587
    s = smtplib.SMTP_SSL("smtp.qq.com", 465)
    s.set_debuglevel(1)
    s.login(sender,passWord)
    #给receivers列表中的联系人逐个发送邮件
    for item in receivers:
        msg['To'] = to = item
        s.sendmail(sender,to,msg.as_string())
        print('Success!')
    s.quit()
    print ("All emails have been sent over!")
 except smtplib.SMTPException as e:
    print ("Falied,%s",e)
