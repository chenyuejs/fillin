from selenium import webdriver,common
from selenium.webdriver.common.keys import Keys
import send
import config




if __name__ == "__main__":
    option = webdriver.ChromeOptions()
    option.add_argument('headless')
    driver = webdriver.Chrome(options=option)
    driver.get('http://xgsys.swjtu.edu.cn/SPCP/Web/StuRegisterInfo.aspx')
    dr = driver.find_element_by_id('code-box')
    code=dr.get_attribute('textContent')#验证码
    ID_elem = driver.find_element_by_id("StudentId")
    ID_elem.send_keys(config.usr_number)
    name_elem = driver.find_element_by_id("Name")
    name_elem.send_keys(config.usr_name)
    card_elem = driver.find_element_by_id("StuCard")
    card_elem.send_keys(config.usr_id)
    code_elem = driver.find_element_by_id("codeInput")
    code_elem.send_keys(code)
    button_elem=driver.find_element_by_id("Button4").click()
    if len(driver.find_elements_by_id("layui-layer1"))!=0:
        print ('今日已填写，或身份信息填写错误！')
        driver.quit()
    else:
            print ('登陆成功!')
            checkbox=driver.find_element_by_id("Checkbox1")
            checkbox.click()
            submit=driver.find_element_by_id("Save_Btn").click()
            if len(driver.find_elements_by_id("layui-layer1"))!=0:
                print ('登记成功！')
                send.send_email()
                driver.quit()