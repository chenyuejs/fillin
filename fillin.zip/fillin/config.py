usr_number='201711xxxx'# 对应替换为你的学号
usr_name='xx'# 对应替换为你的姓名
usr_id='xxxxxx'# 对应替换为你身份证后六位
