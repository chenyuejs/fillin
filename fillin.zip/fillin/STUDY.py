def city_country():
    mix={'Chinese':'Beijing','Japan':'Tokyo','America':'Newyork'}
    return mix;
for m,n in city_country().items():
    print(m+n)