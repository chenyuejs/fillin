##调用百度地图api进行地理编码处理
##author_email：cchenyuee@outlook.com

import requests
import numpy as np
import pandas as pd

place=[0 for i in range(16)]
place[0]=['四川省成都市蒲江县鹤山镇']
place[1]=['四川省成都市蒲江县寿安镇','四川省成都市蒲江县长秋乡']
place[2]=['四川省成都市蒲江县大塘镇','四川省成都市蒲江县甘溪镇','四川省成都市蒲江县大兴镇','四川省成都市蒲江县西来镇','四川省成都市蒲江县复兴乡']
place[3]=['四川省成都市蒲江县成佳镇','四川省成都市蒲江县朝阳湖镇','四川省成都市蒲江县白云乡','四川省成都市蒲江县光明乡']
place[4]=['新津']
place[5]=['武侯区','锦江区','青羊区','金牛区','成华区','龙泉驿区','温江区','新都区','青白江区','双流区','郫都区','大邑县','金堂县','新津县','都江堰市','彭州市','邛崃市','蒲江县','简阳市']
place[6]=['眉山']
place[7]=['攀枝花','四川省凉山自治州']
place[8]=['资阳','乐山','雅安','自贡','内江','宜宾','泸州']
place[9]=['广安','南充','达州','巴中','广元','德阳','绵阳','四川省甘孜自治州','四川省阿坝自治州']
place[10]=['重庆']
place[11]=['云南','贵州']
place[12]=['山东','安徽','浙江','江苏','上海','福建']
place[13]=['广西','广东','海南','江西','湖北','湖南','河南','江西','香港岛','澳门国际机场','台中']
place[14]=['内蒙古','山西','河北','山东','北京','天津','辽宁','吉林','黑龙江']
place[15]=['拉萨','青海','新疆','甘肃','宁夏','陕西']
data=[0 for i in range(16)]

url='http://api.map.baidu.com/geocoding/v3/?address=&output=json&ak='
for i in range(16):
    lng=[]
    lat=[]
    for j in place[i]:
        config={
               'address':j,
               'ak':'LOdRlZ1gl6KEYTrcZWFwi4dqZzCSFLGL'
               }
        req=eval(requests.get(url,config).text)
        if req['status']==0:
         lng.append(req['result']['location']['lng'])
         lat.append(req['result']['location']['lat'])
        else:
            print (str(i)+':'+str(j))
    if lng!=[]:
       lng_avg=np.mean(lng)
       lat_avg = np.mean(lat)
       data[i]=[lng_avg,lat_avg]
print (data)