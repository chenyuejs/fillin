
import json
import os
from io import BytesIO
import requests
from PIL import Image

s = requests.session()
re=s.get("http://xgsys.swjtu.edu.cn/SPCP/Web/UserLogin.aspx")
print (re.content)